﻿



<!DOCTYPE html>
<html class="no-js"> 

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Career | Dodla Dairy</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-responsive.min.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/sl-slide.css">
<script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
 
<!--<link rel="shortcut icon" href="images/ico/favicon.ico">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">-->

<style>
/* Table 1 Style */
table.table1{
    font-size: 13px;
    line-height: 1.4em;
    font-style: normal;
    border-collapse:separate;
}
.table1 thead th{
    padding:8px;
	font-weight: bold;
	background: #060;
		border-top: 4px solid #aabcfe;
	border-bottom: 1px solid #fff;
	color: #FFF;
}
.table1 thead th:empty{
    background:transparent;
    border:none;
}
.table1 tbody th{
	font-size: 13px;
	font-weight: normal;
	padding: 8px;
	background: #b9c9fe;
	border-top: 4px solid #aabcfe;
	border-bottom: 1px solid #fff;
	color: #039;
}
.table1 tbody td{
	padding: 8px;
  background: whitesmoke;
  border-bottom: 1px solid #fff;
  color: black;
  border-top: 1px solid transparent;
}
#box-table-a tr:hover td
{
	background: #CCC;
	color:#060;
}

	</style>

</head>
<body>
 <div style="z-index:9999999999999999; position:absolute; padding-left:5%;" class="responsive">
 <a href="index.html"><img src="images/logo2.png" class="responsive" style="z-index:9999999999999999;"></a>
 </div>

<div class="span6">
 <div style="z-index:9999999999999999; float:right; position:absolute; padding-left:80%;">
 <ul class="social pull-right">
   <li><a href="https://www.facebook.com/dodlamilk/" target="_blank"><i class="icon-facebook-sign"></i></a></li> 
   <li><a href="https://www.youtube.com/watch?v=PoeGhOQB74k" target="_blank"><i class="icon-youtube-sign"></i></a></li>
 </ul>
 </div>
 </div>

<div style="background:#fff;">
 <img src="images/sample/slider/inner_30.jpg" width="100%" align="middle" alt="ourValues">
</div>
<header class="navbar navbar-fixed-top">
<div class="navbar-inner">
<div class="container">
<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</a>
<!--<a id="logo" class="pull-left" href="index-2.html"></a>-->
<div class="nav-collapse collapse pull-right">
<ul class="nav">
<li class="active"><a>&nbsp;</a></li>

<!--<li class="active"><a href="index.html">Home</a></li>-->
<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Home<i class="icon-angle-down"></i></a>
      <ul class="dropdown-menu">
      <li><a href="index.html">Company Overview</a></li>
	  <li><a href="chairmanmessage.html">Chairman's Message </a></li>
      <li><a href="directors.html">Directors</a></li>
      <li><a href="our-values.html">Our Values</a></li>
      <li><a href="our-team.html">Our Team</a></li>
	  <li><a href="corporatebrochure.html">Corporate Brochure </a></li>
      <li><a href="images/CSR-DDL-V.0.2.pdf" target="_blank">CSR Policy </a></li>
      </ul>
</li>
<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products <i class="icon-angle-down"></i></a>
      <ul class="dropdown-menu">
      <li><a href="products.html">Products Views</a></li>
      <li><a href="dodlamilk.html">Milk</a></li>
      <li><a href="dodla-curd.html">Curd</a></li>
      <li><a href="dodla-ghee.html">Ghee</a></li>
      <li><a href="dodla-paneer.html">Paneer</a></li>
      <li><a href="dodla-doodh-peda.html">Doodh Peda</a></li>
      <li><a href="dodla-butter-milk.html">Butter Milk</a></li>
      <li><a href="dodla-flavoured-milk.html">Flavoured Milk</a></li>
      <li><a href="dodla-cooking-butter.html">Cooking Butter</a></li>
      
      </ul>
</li>
<li><a href="procurement.html">Procurement</a></li>
<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Plants <i class="icon-angle-down"></i></a>
      <ul class="dropdown-menu">
      <li><a href="ops.html">Our Packing Stations</a></li>
      <li><a href="nellore.html">Nellore</a></li>
      <li><a href="badvel.html">Badvel</a></li>
      <li><a href="koppal.html">Koppal</a></li>
      <li><a href="kurnool.html">Kurnool</a></li>
      <li><a href="palamaneer.html">Palamaneer</a></li>
      <li><a href="penumur.html">Penumur</a></li>
      <li><a href="sattenapalley.html">Sattenapalley</a></li>
      <li><a href="tumkur.html">Tumkur</a></li>
      <li><a href="tanuku.html">Tanuku</a></li>
      <li><a href="dharmapuri.html">Dharmapuri</a></li>
      <li><a href="hyderabad.html">Hyderabad</a></li>
      
      </ul>
      
      
      
      
</li>
<!--<li><a href="sales.html">Sales</a></li>-->
<li><a href="financials.html">Financial Highlights</a></li>
<!--<li class="dropdown active">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> Financial Highlights <i class="icon-angle-down"></i></a>
      <ul class="dropdown-menu">
      <li><a href="chairmanmessage.html">Chairman's Message </a></li>
      <li><a href="financials.html">Financial Highlights</a></li>
      <li><a href="annualreport.html">Annual Report 2014-15</a></li>
      
      </ul>
</li>-->
<li><a href="overseas.html">Overseas</a></li>
<li class="active"><a href="career.html">Careers</a></li>
<!--<li><a href="feedback.html">Feed back</a></li>-->
<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> Contact <i class="icon-angle-down"></i></a>
      <ul class="dropdown-menu">
      <li><a href="contact.html">Corporate Office </a></li>
      <li><a href="salesoffice.html">Sales Office</a></li>
      <li><a href="packingstations.html">Packing Stations</a></li>
      <li><a href="chillingcenters.html">Chilling Centers</a></li>
      
      </ul>
</li>
<!--<li class="login">
<a data-toggle="modal" href="#loginForm"><i class="icon-lock"></i></a>
</li>-->
</ul>
</div> 
</div>
</div>
</header>
 
<!--<section class="title">
<div class="container">
<div class="row-fluid">
<div class="span6">
<h1>Career</h1>
</div>
<div class="span6">
<ul class="breadcrumb pull-right">
<li><a href="index.html">Home</a> <span class="divider">/</span></li>

<li class="active">Current Openings</li>
</ul>
</div>
</div>
</div>
</section>-->
 <!--<img src="images/plants/plant.jpg" width="100%" align="middle" alt="ourValues">-->
 <script type="text/javascript">
$('head').append('<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">  <title> Career Dodla Dairy-India</title>        <meta name="description" content=" ">        <meta name="author" content="pixel-industry">        <meta name="keywords" content=" ">    <meta name="viewport" content="initial-scale=1, maximum-scale=1, width=device-width"> ');

function edt_title(title)
{
 if(confirm('Are you sure to apply for '+title+' position?'))
 {
  window.location.href='resumeSubmission1.php?edit_title='+title;
 }
}
	</script>

<section id="about-us" class="container main">
<div class="row-fluid">
<div class="span8">
<h2>Current Openings</h2>
<div class="8u skel-cell-important">
					<div id="content">

						<!-- Content -->
					
							<article>
								 
									<ul>
									<table class="table1" id="box-table-a">
<thead>
<tr>
<th>Title</th>
<th>Job Summary</th>
<th>Location</th>
<th>Apply</th>
</tr></thead><tr align="center"><td>Executive / Sr. Executive (Purchase)</td><td><a href="http://www.dodladairy.com/jobSummary/Sr._Executive_Mtrls.-Corporate_Office.doc"  target="_new">Click Here</a></td><td>Hyderabad, Tumkur (karnataka) & Gundrampalli, Near Choutappal (Telangana)</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>Regional Manager (Milk Procurement)</td><td><a href="http://www.dodladairy.com/jobSummary/Regional_Manager_or_Incharge.doc"  target="_new">Click Here</a></td><td>Indragi, Karnataka</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>Assistant Manager / Manager (F & A, Internal audit)</td><td><a href="http://www.dodladairy.com/jobSummary/M_Manpower_Requisition_Form_.doc"  target="_new">Click Here</a></td><td>Corporate Office, Hyderabad & Choutappal Telangana</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>Manager (Production)</td><td><a href="http://www.dodladairy.com/jobSummary/Plant_Manager_or_Dy_Manager.doc"  target="_new">Click Here</a></td><td>Tumkur (karnataka) & Nellore (A.P)</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>Head (Milk Procurement)</td><td><a href="http://www.dodladairy.com/jobSummary/HEAD_PROCUREMENT.docx"  target="_new">Click Here</a></td><td>Corporate Office, Hyderabad & Choutappal Telangana</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>IT Executive</td><td><a href="http://www.dodladairy.com/jobSummary/IT_Executive.docx"  target="_new">Click Here</a></td><td>Corporate Office, Hyderabad & Choutappal Telangana</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>Dy. Manager /Asst. Manager - Quality Assurance</td><td><a href="http://www.dodladairy.com/jobSummary/Manager_(Quality_Assurance).doc"  target="_new">Click Here</a></td><td>Choutappal, Telangana & Hyderabad</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>Area Sales Manager - Milk Sales</td><td><a href="http://www.dodladairy.com/jobSummary/Area_Sales_Manager_-_Milk_Sales.doc"  target="_new">Click Here</a></td><td>Bangalore & Indragi (Karnataka)</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr><tr align="center"><td>Sales Executive (Dairy Products)</td><td><a href="http://www.dodladairy.com/jobSummary/SALES_EXECUTIVE.docx"  target="_new">Click Here</a></td><td>Ahmadabad, Kolkata, Jodhpur, Indore, Gandhidahm, Surath, Rajkot, Bhavanagar, Jamnagar, Bhuj, Mehsana, Himmathnagar, Bangalore, Hyderabad & Chennai</td><td class='warning'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#exampleModal' >Apply Now</button></td></tr></table>		</ul>
									

	                          </article>
				
					</div>
			</div>

<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Open modal for @mdo</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@fat">Open modal for @fat</button>
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@getbootstrap">Open modal for @getbootstrap</button>
...more buttons...-->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Resume Submission Form</h4>
      </div>
      <div class="modal-body">
        <form action="careers_mail.php" enctype="multipart/form-data" method="post">
          <div class="form-group">
            <!--<label for="recipient-name" class="control-label">Name:</label>-->
            <input type="text" class="form-control" placeholder="Name" name="name" required>
            <input type="text" class="form-control" placeholder="Email"  name="email" required>
          </div>
          <div class="form-group">
            <!--<label for="recipient-name" class="control-label">Name:</label>-->
            <input type="text" class="form-control" style="width:435px;" placeholder="Phone.no" name="mobile" required>
            <!--<input type="text" class="form-control" placeholder="Email" >-->
          </div>
          <div class="form-group">
            <label class="control-label" required="required">Applying For:</label>
            <!--<input type="text" style="width:436px;" class="form-control" placeholder="Name" id="recipient-name">-->
            <select class="form-control" style="width:460px;" id="recipient-name" name="select">
              <option>Select Type</option>
              <option>Accounts Assistant - Hubli, Karnataka</option>
              <option>Area Manager (Milk Procurement) - Tanuku, A.P</option>
              <option>Area Sales Manager (Milk Sales) - Chennai</option>
              <option>Area Sales Manager (Milk Sales) - Hyderabad</option>
              <option>Area Sales Manager (Milk Sales) - Tanuku, A.P</option>
              <option>Asst. Manager (Purchase) - Near Choutappal, Hyderabad</option>
              <option>Executive (Accounts) - Ahmedabad</option>
              <option>Executive (Ice Cream mateiral Purchase) - Hyderabad</option>
              <option>Executive or Jr. Executive (Materials) - Hyderabad</option>
              <option>Head - Sales &amp; Marketing (Corporate Office)- Hyderabad</option>
              <option>Head - Quality Control - Hyderabad</option>
              <option>Manager (Sales & Marketing) - Dairy Short life Products -Hyderabad</option>
              <option>Manager (Sales & Marketing) - Ice Cream -Hyderabad</option>
              <option>Manager or Dy. Manager (FP & A) - Hyderabad</option>
              <option>Manager or Dy. Manager (Quality Control) - Nellore</option>
              <option>Plant Manager (Production & Maint.) - Palacode, Tamil Nadu</option>
              <option>Sr. Executive (FP & A) - Hyderabad</option>
              <option>Sr.Manager or Manager (Dairy Products Sales & Mktg.) - Hyderabad</option>
              
              <option>Sr. Manager / AGM - HR - MBA from premier Institutes like XLRI, TISS and SIBM</option>
              <option>Head - I T</option>
              <option>Executive - ERP - Materials</option>
              <option>Jr Executive - Materials</option>
              <option>Head - Milk procurement</option>
              <option>Head - Materials</option>
              <option>Sales Executive (Dairy Products)</option>
              <option>Manager (Distribution)</option>
              
            </select>
           
          </div>
          <div class="form-group">
            <!--<label for="message-text" class="control-label">Message:</label>-->
            <textarea class="form-control" placeholder="Additional Info" style="width:430px; height:100px" id="message-text" name="text" ></textarea>
          </div>
          <div class="form-group">
            <!--<label for="message-text" class="control-label">Upload your Resume :</label>-->
            Upload your Resume : 
            &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="uploadedfile" id="resume" required>
          </div>
          <div class="form-group">
           <!-- <label class="control-label">What is 2+2 = ? (Anti-spam) :</label>-->
           What is 2+2 = ? (Anti-spam) :
            <input type="text" class="form-control" placeholder="Type Here">
             <button type="submit" class="btn btn-primary"  name="Submit" class="submit">Submit</button>
          </div>
      
       
       
      
        </form>
      </div>
<!--      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Send message</button>
      </div>
-->    </div>
  </div>
</div>



</div>

<div class="span4">
<h2>Career</h2>
<div>
<div class="widget">
<ul class="tag-cloud unstyled">
<li><a class="btn btn-mini btn-primary" href="career.html">Why Join Us?</a></li>
<li><a class="btn btn-mini btn-primary" href="current_openings.php" style="background-color:#393185;">Current Openings </a></li>

</ul>
</div>
</div>

<!--<div class="progress"><a href="career.html"><div class="bar" style="width: 100%; text-align:left; padding-left:10px; background-color:#393185;">Why Join Us?</div></a></div>
<div class="progress"><a href="current_openings.html"><div class="bar" style="width: 100%; text-align:left; padding-left:10px;">Current Openings</div></a></div>
-->
</div>


<!-----------------------scroll---------------------->
<!--<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="span4">
   <h3>Vision & Mission</h3>
		<div class="accordion" id="accordion2">
			<div class="accordion-group">
				<div class="accordion-heading">
					<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
Vision</a>
				</div>
				<div id="collapseOne" class="accordion-body collapse">
					<div class="accordion-inner">To be a world class dairy company by providing high quality Products and Services.
					</div>
				</div>
			</div>
			<div class="accordion-group">
				<div class="accordion-heading">
					<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
Mission</a>
				</div>
			<div id="collapseTwo" class="accordion-body collapse">
				<div class="accordion-inner">To supply good and safe milk products consistently through continual improvement of our systems and practices.
				</div>
			</div>
		</div>
		
</div>-->

<!-----------------------scroll---------------------->

</div>



<hr>

</div>
</section>
 
 <!--<section id="clients" class="main">
<div class="container">
<div class="row-fluid">
<div class="span1">
<div class="clearfix">
<div class="pull-right">
<a class="prev" href="#myCarousel" data-slide="prev"><i class="icon-angle-left icon-large" style="font-size:20px;"></i></a> <a class="next" href="#myCarousel" data-slide="next"><i class="icon-angle-right icon-large" style="font-size:20px;"></i></a>
</div>
</div>

</div>
<div class="span11">
<div id="myCarousel" class="carousel slide clients">
 
<div class="carousel-inner">
<div class="active item">
<div class="row-fluid">
<ul class="thumbnails">
<li class="span3"><a href="#"><img src="images/sample/clients/001.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/002.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/003.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/004.jpg"></a></li>
</ul>
</div>
</div>
<div class="item">
<div class="row-fluid">
<ul class="thumbnails">
<li class="span3"><a href="#"><img src="images/sample/clients/005.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/006.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/007.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/008.jpg"></a></li>
</ul>
</div>
</div>
<div class="item">
<div class="row-fluid">
<ul class="thumbnails">
<li class="span3"><a href="#"><img src="images/sample/clients/009.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/001.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/002.jpg"></a></li>
<li class="span3"><a href="#"><img src="images/sample/clients/003.jpg"></a></li>
</ul>
</div>
</div>
</div>
 
</div>
</div>
</div>
</div>
</section>-->
 
 
 
 
<section id="bottom" class="main">
 
<div class="container">
 
<div class="row-fluid">
 
<div class="span3">
<h4>ADDRESS</h4>
<ul class="unstyled address">
<li>
<i class="icon-home"></i><strong>Address:</strong> Dodla Dairy Ltd<br>#8-2-293/82/A, 
Plot No-270/Q,
Road No 10-C,
Jubliee Hills, 
Hyderabad – 500 033.
<!--# 6-3-661/8, 
Sangeeth nagar,
Somajiguda, 
Hyderabad,
Telangana -500 082-->
</li>
<li>
<i class="icon-envelope"></i>
<strong>Email: </strong> <a class="__cf_email__" href="#" data-cfemail="473432373728353307222a262e2b6924282a">support@dodladairy.com</a><!--<script data-cfhash='f9e31' type="text/javascript">/* <![CDATA[ */!function(t,e,r,n,c,a,p){try{t=document.currentScript||function(){for(t=document.getElementsByTagName('script'),e=t.length;e--;)if(t[e].getAttribute('data-cfhash'))return t[e]}();if(t&&(c=t.previousSibling)){p=t.parentNode;if(a=c.getAttribute('data-cfemail')){for(e='',r='0x'+a.substr(0,2)|0,n=2;a.length-n;n+=2)e+='%'+('0'+('0x'+a.substr(n,2)^r).toString(16)).slice(-2);p.replaceChild(document.createTextNode(decodeURIComponent(e)),c)}p.removeChild(t)}}catch(u){}}()/* ]]> */</script>-->
</li>
<li>
<i class="icon-globe"></i>
<strong>Website:</strong> www.dodladairy.com
</li>
<li>
<i class="icon-phone"></i>
<strong>Toll Free:</strong> 1800 103 1477
</li>
</ul>
</div>
 
 
<div id="tweets" class="span3">
<h4>OUR COMPANY</h4>
<div>
<ul class="arrow">
<li><a href="about-us.html">About Us</a></li>
<li><a href="products.html">Products</a></li>
<li><a href="procurement.html">Procurement</a></li>
<li><a href="plants.html">Plants</a></li>
<li><a href="sales.html">Sales</a></li>
<li><a href="chairmanmessage.html">Investors</a></li>
<li><a href="overseas.html">Overseas</a></li>
<li><a href="career.html">Careers</a></li>
<li><a href="feedback.html">Feed back</a></li>
<li><a href="contact.html">Contact us</a></li>

</ul>
</div>
</div>
 

 
<div id="archives" class="span3">
<h4>Plants</h4>
<div>
<ul class="arrow">
<li><a href="nellore.html">Nellore</a></li>
<li><a href="badvel.html">Badvel</a></li>
<li><a href="koppal.html">Koppal</a></li>
<li><a href="kurnool.html">Kurnool</a></li>
<li><a href="palamaneer.html">Palamaneer</a></li>
<li><a href="penumur.html">Penumur</a></li>
<li><a href="sattenapalley.html">Sattenapalley</a></li>
<li><a href="tumkur.html">Tumkur</a></li>
<li><a href="tanuku.html">Tanuku</a></li>
</ul>
</div>
</div>
 
<div class="span3">
<h4>Dodla Milk - Kannada Ad Film</h4>
<div class="row-fluid first">
<!--<video width="100%" height="200px" controls>
  <source src="images/DODLA-DIARY-40-SEC-KANNADA.mov" type="video/mp4">
  <source src="images/DODLA-DIARY-40-SEC-KANNADA.mov" type="video/ogg">
  
</video>-->
<!--<video src="images/DODLA-DIARY-40-SEC-KANNADA.mov" width="100%" height="200px"></video>-->
<iframe width="100%" height="200px" src="https://www.youtube.com/embed/PoeGhOQB74k" frameborder="0" allowfullscreen></iframe>
<!--<ul class="thumbnails">
<li class="span3">
<a href="#" title="01 (254) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (254)"></a>
</li>
<li class="span3">
<a href="#" title="01 (196) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (196)"></a>
</li>
<li class="span3">
<a href="#" title="01 (65) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (65)"></a>
</li>
<li class="span3">
<a href="#" title="01 (6) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (6)"></a>
</li>
</ul>
</div>
<div class="row-fluid">
<ul class="thumbnails">
<li class="span3">
<a href="#" title="01 (6) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (6)"></a>
</li>
<li class="span3">
<a href="#" title="01 (254) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (254)"></a>
</li>
<li class="span3">
<a href="#" title="01 (196) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (196)"></a>
</li>
<li class="span3">
<a href="#" title="01 (65) by Victor1558, on Flickr"><img src="images/photo_unavailable_s.png" width="75" height="75" alt="01 (65)"></a>
</li>
</ul>-->
</div>
</div>
</div>
 
</div>
 
</section>
 
 
<footer id="footer">
<div class="container">
<div class="row-fluid">
<div class="span5 cp">
&copy; 2016 <a target="_blank" href="www.dodladairy.com" title="Dodla Dairy">Dodla Dairy</a>. All Rights Reserved.  |  Design By <a href="http://www.active.in/" target="_blank">active.in</a></div>
 
<div class="span6">
<!--<ul class="social pull-right">
<li><a href="#"><i class="icon-facebook"></i></a></li>
<li><a href="#"><i class="icon-twitter"></i></a></li>
<li><a href="#"><i class="icon-pinterest"></i></a></li>
<li><a href="#"><i class="icon-linkedin"></i></a></li>
<li><a href="#"><i class="icon-google-plus"></i></a></li>
<li><a href="#"><i class="icon-youtube"></i></a></li>
<li><a href="#"><i class="icon-tumblr"></i></a></li>
<li><a href="#"><i class="icon-dribbble"></i></a></li>
<li><a href="#"><i class="icon-rss"></i></a></li>
<li><a href="#"><i class="icon-github-alt"></i></a></li>
<li><a href="#"><i class="icon-instagram"></i></a></li>
</ul>-->
</div>
<div class="span1">
<a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a>
</div>
 
</div>
</div>
</footer>
 
 
<div class="modal hide fade in" id="loginForm" aria-hidden="false">
<div class="modal-header">
<i class="icon-remove" data-dismiss="modal" aria-hidden="true"></i>
<h4>Login Form</h4>
</div>
 
<div class="modal-body">
<form class="form-inline" action="http://shapebootstrap.net/demo/html/nova/index.html" method="post" id="form-login">
<input type="text" class="input-small" placeholder="Email">
<input type="password" class="input-small" placeholder="Password">
<label class="checkbox">
<input type="checkbox"> Remember me
</label>
<button type="submit" class="btn btn-primary">Sign in</button>
</form>
<a href="#">Forgot your password?</a>
</div>
 
</div>
 
<script src="js/vendor/jquery-1.9.1.min.js"></script>
<script src="js/vendor/bootstrap.min.js"></script>
<script src="js/main.js"></script>
</body>

</html>
